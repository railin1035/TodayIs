package com.ghc.tdi_main.Schedule;

public class schedule_list_items {
    public String s_title;
    public String s_startDate;
    public String s_endDate;
    public String s_repeat;
    public String s_dDay;
    public String s_color;
    public String s_place;
    public String s_memo;

}

