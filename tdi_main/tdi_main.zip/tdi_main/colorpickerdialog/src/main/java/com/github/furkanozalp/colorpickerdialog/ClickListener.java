package com.github.furkanozalp.colorpickerdialog;

public interface ClickListener {

    void onClick(int color);
}
