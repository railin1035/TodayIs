package top.defaults.colorpicker;

import android.view.MotionEvent;

public interface Updatable {

    void update(MotionEvent event);
}
